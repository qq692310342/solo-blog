title: Spring Cloud|02 Spring Cloud简介
date: '2019-08-13 09:16:35'
updated: '2019-08-13 09:16:35'
tags: [SpringCloud]
permalink: /articles/2019/08/13/1565658995826.html
---
![](https://img.hacpai.com/bing/20190607.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

几点说明
1、本系列Spring Cloud的博客参考了方志朋所著《深入理解Spring Cloud与微服务构建》；
2、大家如果想更加深入的理解Spring Cloud 建议多实战、多看书；
## 简介
Spring Cloud是基于Spring Boot的，而Spring Boot的特点就是简化了开发和部署的过程，具体体现在Spring Boot底层实现的时候会自动加载默认配置，而在自主配置的配置文件、配置类中的配置会覆盖框架默认配置。简化部署体现在内置tomcat服务器，开发者无需自主配置就能够直接部署上线；

Spring Cloud的最主要的设计核心就是基于组件开发的模式，提供了一系列的便捷的开发组件，可以帮助我们迅速的开发出一个迷你分布式微服务系统，而说白了，Spring Cloud也是通过提前封装好其他的一些技术来实现的便捷组件，例如：包装了开源的Netflix OSS组件，实现了一套通过注解、JAVA配置类和模板开发的微服务框架；

## 常用组件
1. 服务注册与发现中心Eureka
利用Eureka可以很快速得实现一个注册中心，同时Eureka还提供了服务的健康检测、友好的UI界面让我们可以一目了然得看到整个注册中心的运行状况以及微服务的状况。
2. 服务熔断器Hystrix
Hystrix是一个熔断组件，除了能够实现服务熔断之外，它还提供了服务降级、服务限流等功能，同时Hystrix还有一套完善的健康检测，以及熔断器健康数据的API接口，旗下的组件Hystrix Dashboard提供了单个服务熔断器的健康状态数据的UI界面显示，让整个微服务的健康状态得到更好的展示，方便维护。
3. 负载均衡组件Ribbon
Ribbon组件能够实现系统提供的一些负载均衡的策略轮询、随机等算法，同时也能够自定义负载均衡策略，Ribbon与网关Zuul配合使用可以很容易的实现相关的均衡策略，根据请求来负载均衡到集群服务器，同时Ribbon与feign、RestTemplate配合可以实现消费方的负载均衡的策略。
4. 路由网关Zuul
Zuul组件可以实现我们智能路由和过滤的功能，内部服务器的API接口统一通过网关进行对外的统一暴露，这样做能够更加安全的对微服务的保护，Zuul的智能过滤是通过自定义的拦截器来实现的，通过智能过滤可以剔除掉很多的非法访问等行为。
5. Spring Cloud Config
Spring Cloud Config提供了配置文件的统一的云端管理，通常配合GitHub使用，将所以微服务的配置文件统一放在远程仓库中，Server端统一读取仓库的配置文件，Client端通过读取Server的配置文件来实现统一管理配置，通常情况下，Spring Cloud Config和Spring Cloud Bus相互配合刷新指定Client或所有的Client配置文件。
6. Spring Cloud Security
Spring Cloud Security 是对Spring Security的封装，向服务提供用户验证的权限认证，一般来说它会配合Spring Security OAuth2组件一同使用，通过搭建一个微服务授权中心，验证Token或者JWT这种形式对整个微服务系统进行用户校验。
7. Spring Cloud Sleuth
Spring Cloud Sleuth是一个分布式的链路跟踪组件，它封装了Dapper、Zipkin和Kibana等组件，通过它可以知道服务与服务之间的依赖关系，便于后期维护与管理。
8. Spring Cloud Stream
Spring Cloud Stream组件是对数据流操作的，内部封装了Redis以及消息队列rabbitMQ、kafka、ActiveMQ等消息组件。
9. Feign
Feign是一个声明式的远程调度的组件，通常用在消费者端，通过Feign可以便捷的远程调用在注册中心的微服务的相关接口，实现远程调用，这也是微服务得以运行的基础。
10. Spring Cloud Task
Spring Cloud Task基于Spring Task，主要用于提供任务调度以及任务管理等方面的功能，在分布式事务中会用到。

---
END
2019年8月13日09:16:29