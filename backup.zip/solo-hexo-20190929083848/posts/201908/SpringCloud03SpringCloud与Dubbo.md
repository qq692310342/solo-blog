title: Spring Cloud|03 Spring Cloud与Dubbo
date: '2019-08-16 18:22:50'
updated: '2019-08-16 18:22:50'
tags: [面试, SpringCloud]
permalink: /articles/2019/08/16/1565950970456.html
---
![](https://img.hacpai.com/bing/20190105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

几点说明  
1、本系列Spring Cloud的博客参考了方志朋所著《深入理解Spring Cloud与微服务构建》；  
2、大家如果想更加深入的理解Spring Cloud 建议多实战、多看书；

## Dubbo简介
### 介绍
Dubbo是阿里巴巴公司开源的一个高性能优秀的服务框架，使得应用可通过高性能的 RPC 实现服务的输出和输入功能，可以和Spring框架无缝集成。

Dubbo是一款高性能、轻量级的开源Java RPC框架，它提供了三大核心能力：

1. 面向接口的远程方法调用:封装了长连接的NIO框架，例如:Netty、Mina等等；

2. 智能容错和负载均衡；

3. 服务自动注册和发现；集成Apache的Zookeeper组件，用于用户的注册与发现；

### Dubbo框架的运行流程如下：
1. 服务提供者注册进入服务注册中心；
2. 服务消费者订阅服务；
3. 服务消费者发现服务；
4. 服务消费者通过远程调度来找到服务提供者进行服务的消费；
5. 服务消费者和服务提供者定时发送心跳数据到服务监控中心用于记录调用次数和时间；


### Dubbo的优点：
1. 连通性：服务注册中心、服务提供者、服务消费者、服务监控中心都是长连接；
2. 健壮性：监控中心宕机不会影响其他的服务的正常进行，服务器集群配置的话，任意一个服务的宕机都不会影响整体的服务的运行状况；
3. 伸缩性：可以动态增减注册中心与服务的实例数量；
4. 升级性：服务器集群升级，不会对现有架构造成压力； 

## Spring Cloud 与 Dubbo
| 服务关注点 | Spring Cloud | Dubbo |
| --- | --- | --- |
|  配置管理 | config | 无 |
|  服务发现 | Eureka、Consul、Zookeeper | Zookeeper |
| 负载均衡 | Ribbon| 自带 |
| 网关| Zuul | 无 |
| 分布式追踪 | Spring Cloud Sleuth | 无 |
| 容错| Hystrix | 不完善 |
| 通信方式 | HTTP、Message | RPC、NIO |
| 安全模块 |Spring Cloud Security | 无 |

### 其他方面：
1. 更新频率
Spring Cloud保持着十分高频率的更新，并且社区活跃度也很高，这对于一个架构来说是一件十分利好的事情，至少Spring Cloud是在飞速发展的；
而Dubbo自从2013年3月开始暂停了更新，接下来的五年时间里都没有进行技术上的更新迭代，直到2017年9月才重新更新；
2. 开发风格
Spring Cloud更趋向使用注解+JavaBean的配置方式的敏捷开发；
Dubbo则趋向于使用Spring XML的配置方式；
3. 通信方式
Spring Cloud大多数使用的是基于HTTP Restful的风格，服务与服务之间完全无关、解耦合；
Dubbo则是基于RPC的远程调用方式，对于平台、接口、语言有强依赖；跨平台调用服务比较困难，需要额外写中间件；

---
END
2019年8月13日10:12:22
