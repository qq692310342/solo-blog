title: JVM|01基础指令
date: '2019-08-15 09:39:23'
updated: '2019-08-15 10:09:19'
tags: [JVM]
permalink: /articles/2019/08/15/1565833163810.html
---
![](https://img.hacpai.com/bing/20180105.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 我们为什么要对jvm做优化？  
在本地开发环境中我们很少会遇到需要对jvm进行优化的需求，但是到了生产环境，我们  
可能将有下面的需求：  
运行的应用“卡住了”，日志不输出，程序没有反应  
服务器的CPU负载突然升高  
在多线程应用下，如何分配线程的数量？  
……  
我们不仅要让程序能跑起来，而且是可以跑的更快！可以分析解决在生产环境中所遇到的各种“棘手”的问题。
**博主使用的jdk版本为1.8**

## JVM的运行参数
 在jvm中有很多的参数可以进行设置，这样可以让jvm在各种环境中都能够高效的运行。  绝大部分的参数保持默认即可。
### 标准参数  
-help  
-version等
**实战**
1. 查看jdk版本
```
[root@hadoop101 ~]# java -version
java version "1.8.0_111"
Java(TM) SE Runtime Environment (build 1.8.0_111-b14)
Java HotSpot(TM) 64-Bit Server VM (build 25.111-b14, mixed mode)
# ‐showversion参数是表示，先打印版本信息，再执行后面的命令，在调试时非常有用，  
后面会使用到。  
```
2. 通过-D 设置系统属性参数 
```
public class JvmTest {
    public static void main(String[] args) {
        String str = System.getProperty("str");
        if(str==null){
            System.out.println("jeff");
        }else {
            System.out.println(str);
        }
    }
}
```
在虚拟机上编译运行
```
[root@hadoop101 ~]# javac JvmTest.java 
[root@hadoop101 ~]# java JvmTest
jeff
[root@hadoop101 ~]# java -Dstr=123345 JvmTest
123345
[root@hadoop101 ~]# 
```
3. -server与-client参数
 可以通过-server或-client设置jvm的运行参数。  
它们的区别是Server VM的初始堆空间会大一些，默认使用的是并行垃圾回收器，启  
动慢运行快。  
Client VM相对来讲会保守一些，初始堆空间会小一些，使用串行的垃圾回收器，它  
的目标是为了让JVM的启动速度更快，但运行速度会比Serverm模式慢些。  
JVM在启动的时候会根据硬件和操作系统自动选择使用Server还是Client类型的  
JVM。  
32位操作系统  
如果是Windows系统，不论硬件配置如何，都默认使用Client类型的JVM。  
如果是其他操作系统上，机器配置有2GB以上的内存同时有2个以上CPU的话默  
认使用server模式，否则使用client模式。  
64位操作系统  
只有server类型，不支持client类型

### -X参数 （非标准参数）  
-Xint  
-Xcomp
-Xmixed 等
在解释模式(interpreted mode)下，-Xint标记会强制JVM执行所有的字节码，当然这  
会降低运行速度，通常低10倍或更多。
-Xcomp参数与它（-Xint）正好相反，JVM在第一次使用时会把所有的字节码编译成  
本地代码，从而带来最大程度的优化。  
然而，很多应用在使用-Xcomp也会有一些性能损失，当然这比使用-Xint损失的  
少，原因是-xcomp没有让JVM启用JIT编译器的全部功能。JIT编译器可以对是否  
需要编译做判断，如果所有代码都进行编译的话，对于一些只执行一次的代码就  
没有意义了。  
-Xmixed是混合模式，将解释模式与编译模式进行混合使用，由jvm自己决定，这是  
jvm默认的模式，也是推荐使用的模式

实例：
```
[root@hadoop101 ~]# java -showversion -Xint JvmTest
java version "1.8.0_111"
Java(TM) SE Runtime Environment (build 1.8.0_111-b14)
Java HotSpot(TM) 64-Bit Server VM (build 25.111-b14, interpreted mode)
# interpreted mode
jeff
[root@hadoop101 ~]# java -showversion -Xcomp JvmTest
java version "1.8.0_111"
Java(TM) SE Runtime Environment (build 1.8.0_111-b14)
Java HotSpot(TM) 64-Bit Server VM (build 25.111-b14, compiled mode)
# compiled mode
jeff
[root@hadoop101 ~]# java -showversion  JvmTest
java version "1.8.0_111"
Java(TM) SE Runtime Environment (build 1.8.0_111-b14)
Java HotSpot(TM) 64-Bit Server VM (build 25.111-b14, mixed mode)
# 默认下mixed mode
jeff
```
### -XX参数（使用率较高）  
-XX:newSize  
-XX:+UseSerialGC等

 -XX参数也是非标准参数，主要用于jvm的调优和debug操作。  
-XX参数的使用有2种方式，一种是boolean类型，一种是非boolean类型：  
boolean类型  
格式：-XX:[+-]  
如：-XX:+DisableExplicitGC 表示禁用手动调用gc操作，也就是说调用  
System.gc()无效  
非boolean类型  
格式：-XX:  
如：-XX:NewRatio=1 表示新生代和老年代的比值

### -Xms和-Xmx参数
-Xms与-Xmx分别是设置jvm的堆内存的初始大小和最大大小。 

 
-Xmx2048m：等价于-XX:MaxHeapSize，设置JVM最大堆内存为2048M。  
-Xms512m：等价于-XX:InitialHeapSize，设置JVM初始堆内存为512M。  
适当的调整jvm的内存大小，可以充分利用服务器资源，让程序跑的更快

实例：
```
[root@hadoop101 ~]# java -Xms512m -Xmx1024m JvmTest
jeff
```

### 查看JVM的运行参数
1. 运行java命令时打印参数
-XX:+PrintFlagsFinal
参数有boolean类型和数字类型，值的操作符是=或:=，分别代
表默认值和被修改的值。

2. 查看正在运行的JVM参数
方便显示：我们先启动一个tomcat来观察
```
root@hadoop101 bin]# ./startup.sh 
Using CATALINA_BASE:   /usr/local/tomcat
Using CATALINA_HOME:   /usr/local/tomcat
Using CATALINA_TMPDIR: /usr/local/tomcat/temp
Using JRE_HOME:        /usr
Using CLASSPATH:       /usr/local/tomcat/bin/bootstrap.jar:/usr/local/tomcat/bin/tomcat-juli.jar
Tomcat started.
```

通过jps 或者 jps -l 来查看java进程
```
[root@hadoop101 ~]# jps
3846 Bootstrap
4727 Jps
[root@hadoop101 ~]# jps -l
4737 sun.tools.jps.Jps
3846 org.apache.catalina.startup.Bootstrap
```
获取到端口信息，通过jinfo -flags 端口号来获取运行JVM参数
```
[root@hadoop101 ~]# jinfo -flags 3846
Attaching to process ID 3846, please wait...
Debugger attached successfully.
Server compiler detected.
JVM version is 25.111-b14
Non-default VM flags: -XX:CICompilerCount=2 -XX:InitialHeapSize=31457280 
-XX:MaxHeapSize=482344960 -XX:MaxNewSize=160759808 -XX:MinHeapDeltaBytes=196608 
-XX:NewSize=10485760 -XX:OldSize=20971520 -XX:+UseCompressedClassPointers 
-XX:+UseCompressedOops -XX:+UseFastUnorderedTimeStamps  

Command line:  -Djava.util.logging.config.file=/usr/local/tomcat/conf/logging.properties 
-Djava.util.logging.manager=org.apache.juli.ClassLoaderLogManager -Djdk.tls.ephemeralDHKeySize=2048-Djava.protocol.handler.pkgs=org.apache.catalina.webresources 

-Dcatalina.base=/usr/local/tomcat -Dcatalina.home=/usr/local/tomcat -Djava.io.tmpdir=/usr/local/tomcat/temp 

```
我们可以看到一些熟悉的参数XX:InitialHeapSize、MaxHeapSize等。
我们也可以通过jinfo -flag 参数名 端口号 来看具体某个参数的信息
```
[root@hadoop101 ~]# jinfo -flag MaxHeapSize 3846
-XX:MaxHeapSize=482344960
```

---
End
2019年8月15日09:38:44